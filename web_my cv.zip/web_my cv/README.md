   
<p align="center">
    <img width="400" height="auto" src="https://nebrasapps.com/github/cv.png" alt="Nebras Logo" /> 
</p>


## What's Web CV ❓
<b>
   ‫
   ‫سيرة ذاتية 👨‍⚖️👩‍✈️👨‍🚒🕵️‍♀️👮👨‍🏫👨‍🚀👨‍🎨👩‍🏭 احترافية ويب HTML5, CSS3 بتصميم مرن Respnsive Design مناسبة لجميع أحجام الشاشات 💻📱 تحتوي على المعلومات الأساسية، التعليم، الشهادات، الخبرات، المهارات ... ويمكنك الإضافة والتعديل عليها 🙏 مفتوحة المصدر من تصميم وتطوير <a href="https://nebrasapps.com">فريق نبراس </a>
   <br>
  😍زد فرصك الوظيفية بإبداعك في سيرتك الذاتية 💼    مجاناُ للجميع
</b></br></br>

## Screenshots 🖼️
<b>
<p align="center">
    <img width="auto" height="auto" src="https://nebrasapps.com/github/web_cv3.png" alt="Web CV Screenshot" /> 
   <br><br>
    <img width="auto" height="auto" src="https://nebrasapps.com/github/web_cv4.png" alt="Web CV Screenshot" /> 
   <br><br>
    <img width="auto" height="auto" src="https://nebrasapps.com/github/web_cv1.png" alt="Web CV Screenshot" /> 
   <br><br>
    <img width="auto" height="auto" src="https://nebrasapps.com/github/web_cv2.png" alt="Web CV Screenshot" /> 

</p>


## About Nebras 🔥


<p align="center">
  <b></b>
<img src="https://www.nebrasapps.com/images/bg.png" />
</br></br>
</p>
<p align="right">
<b>
شركة رائدة في التقنيات الحديثة والمتطورة في حلول وتطبيقات الويب والأجهزة الذكية ⌚📱💻 التي تعمل على كل المنصات مثل الأندرويد، الايفون، الويندوز وغيرها. بالإضافة الى تطوير أجهزة وأنظمة تخدم مجال إنترنت الأشياء والحوسبة السحابية. إن خبراءنا الذين يعملون بشغف بإمكانهم تحقيق رؤيتكم و مشاريعكم التقنية في مجالات مختلفة ومشاركتكم النجاح.</br>
رؤيتنا تتجه نحو تقديم خدمة تقنية متطورة عالية الجودة لمواكبة التطور السريع في العالم التقني ورسالتنا توفير أحدث التقنيات في الاسواق العالمية وإعادة رسم الافكار لتوفير أفضل الحلول.
</b>
</p>
</br></br></br>


## Our Clients 💼

   

<p align="center">   
<img width="80" height="80" src="https://www.nebrasapps.com/images/works/bulby/bulby.png"/>&nbsp 
<img width="80" height="80" src="https://www.nebrasapps.com/images/works/BitsJobs/BitsJobs.png"/>&nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/TrusteApp/TrusteApp.png"/>&nbsp
    <img width="80" height="80" src="https://www.nebrasapps.com/images/works/Travel4Arab/Travel4Arab.png"/>&nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/TechCampus/TechCampus.png"/>&nbsp
    <img width="80" height="80" src="https://www.nebrasapps.com/images/works/TrucksGO/TrucksGO.png"/>&nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/SnapJobs/SnapJobs.png"/></br></br>
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/CallDriver/CallDriver.png"/> &nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/CallTech/CallTech.png"/>&nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/CHC/CHC.png"/>  &nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/Hag/Hag.png"/> &nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/MsCare/MsCare.png"/> &nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/Men/Men.png"/> &nbsp
   <img width="80" height="80" src="https://www.nebrasapps.com/images/works/Hadaj/hadaj.png"/>
   </br></br>
   </p>
   <p align="center">   
www.nebrasapps.com
</p>
